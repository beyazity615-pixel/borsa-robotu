"""
indicators.py
--------------
BIST hisseleri için TEK veri kaynağı `tradingview-ta` kütüphanesidir
(screener="turkey", exchange="BIST"). yfinance KESİNLİKLE KULLANILMAZ.

ÖNEMLİ MİMARİ NOT:
tradingview-ta yalnızca TradingView sunucusunun hesapladığı ANLIK
(son bar) gösterge değerlerini döndürür; geçmiş mum/hacim serisi vermez.
Bu yüzden:
  - Vol_SMA20 (20 periyotluk hacim ortalaması) yerel bir geçmiş kaydından
    hesaplanır: bot her çalıştığında güncel hacmi data/volume_history/
    altına ekler ve rolling ortalamayı oradan üretir. Geçmiş biriktikçe
    (ilk ~20 çalıştırmadan sonra) değer daha anlamlı hale gelir; öncesinde
    None döner ve sinyal mantığı bunu güvenle atlar.
  - Aynı mekanizma grafik üretimi (bot.py) için fiyat geçmişini de biriktirir.

Finlab temel analiz skorları finlab_data.json'dan (veya harici bir Finlab
veri kaynağından) okunur ve DataFrame'e eklenir.
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

import pandas as pd
from tradingview_ta import TA_Handler, Interval

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
logger = logging.getLogger("indicators")

# --------------------------------------------------------------------------- #
# Sabitler
# --------------------------------------------------------------------------- #
SCREENER = "turkey"
EXCHANGE = "BIST"

BASE_DIR = Path(__file__).parent
FINLAB_PATH = Path(os.environ.get("FINLAB_DATA_PATH", str(BASE_DIR / "finlab_data.json")))
VOLUME_HISTORY_DIR = BASE_DIR / "data" / "volume_history"
PRICE_HISTORY_DIR = BASE_DIR / "data" / "price_history"
VOLUME_HISTORY_DIR.mkdir(parents=True, exist_ok=True)
PRICE_HISTORY_DIR.mkdir(parents=True, exist_ok=True)

VOL_SMA_WINDOW = int(os.environ.get("VOL_SMA_WINDOW", "20"))

# tradingview-ta çağrıları arasında nazik bekleme (rate-limit / IP ban koruması)
TV_REQUEST_DELAY_SEC = float(os.environ.get("TV_REQUEST_DELAY_SEC", "0.6"))
TV_MAX_RETRIES = int(os.environ.get("TV_MAX_RETRIES", "3"))

OUTPUT_COLUMNS = [
    "Symbol", "Close", "Open", "High", "Low", "Volume",
    "RSI", "ADX", "EMA_50", "EMA_200", "MACD_Hist", "ATR",
    "Vol_SMA20", "TV_Recommendation", "TV_Recommendation_Intraday",
    "Finlab_Score", "Fundamental_OK",
]


# --------------------------------------------------------------------------- #
# Finlab temel analiz verisi
# --------------------------------------------------------------------------- #
def load_finlab_data(path: Path = FINLAB_PATH) -> dict:
    """
    finlab_data.json örnek yapısı:
        {"THYAO": {"Finlab_Score": 78, "Fundamental_OK": true}, ...}
    Dosya bulunamaz/bozuksa boş dict döner; bot çökmez, sadece Finlab
    filtresi o taramada devre dışı kalır (Finlab_Score=0, Fundamental_OK=False).
    """
    if not path.exists():
        logger.warning("finlab_data.json bulunamadı: %s — Finlab filtresi bu turda atlanacak.", path)
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        logger.error("finlab_data.json okunamadı: %s", exc)
        return {}


def get_finlab_row(symbol: str, finlab_db: Optional[dict] = None) -> dict:
    finlab_db = finlab_db if finlab_db is not None else load_finlab_data()
    entry = finlab_db.get(symbol.upper(), {})
    return {
        "Finlab_Score": entry.get("Finlab_Score", 0),
        "Fundamental_OK": bool(entry.get("Fundamental_OK", False)),
    }


# --------------------------------------------------------------------------- #
# Yerel geçmiş biriktirme (hacim SMA + grafik için fiyat serisi)
# --------------------------------------------------------------------------- #
def _append_and_rolling(csv_path: Path, value: float, column: str, window: int) -> Optional[float]:
    now_ts = pd.Timestamp.utcnow().isoformat()
    row = pd.DataFrame([{"timestamp": now_ts, column: value}])
    if csv_path.exists():
        try:
            hist = pd.read_csv(csv_path)
            hist = pd.concat([hist, row], ignore_index=True).tail(500)  # dosya şişmesin
        except (pd.errors.EmptyDataError, OSError):
            hist = row
    else:
        hist = row
    hist.to_csv(csv_path, index=False)

    if len(hist) < window:
        return None
    return float(hist[column].tail(window).mean())


def _update_volume_history(symbol: str, volume: Optional[float]) -> Optional[float]:
    if volume is None:
        return None
    path = VOLUME_HISTORY_DIR / f"{symbol.upper()}.csv"
    return _append_and_rolling(path, volume, "volume", VOL_SMA_WINDOW)


def record_price_history(symbol: str, close: Optional[float]) -> None:
    """Grafik üretimi (bot.py) için yerel fiyat geçmişi kaydı."""
    if close is None:
        return
    path = PRICE_HISTORY_DIR / f"{symbol.upper()}.csv"
    _append_and_rolling(path, close, "close", window=1)  # window burada sadece kayıt amaçlı


def load_price_history(symbol: str) -> pd.DataFrame:
    path = PRICE_HISTORY_DIR / f"{symbol.upper()}.csv"
    if not path.exists():
        return pd.DataFrame(columns=["timestamp", "close"])
    try:
        return pd.read_csv(path, parse_dates=["timestamp"])
    except (pd.errors.EmptyDataError, OSError):
        return pd.DataFrame(columns=["timestamp", "close"])


# --------------------------------------------------------------------------- #
# TradingView-TA veri çekimi
# --------------------------------------------------------------------------- #
def _fetch_tv_analysis(symbol: str, interval: str, retries: int = TV_MAX_RETRIES):
    last_exc = None
    for attempt in range(1, retries + 1):
        try:
            handler = TA_Handler(
                symbol=symbol,
                screener=SCREENER,
                exchange=EXCHANGE,
                interval=interval,
            )
            analysis = handler.get_analysis()
            time.sleep(TV_REQUEST_DELAY_SEC)
            return analysis
        except Exception as exc:  # tradingview-ta ağ/parse hatalarını genel Exception fırlatır
            last_exc = exc
            logger.warning("TV veri çekim hatası (%s, deneme %d/%d): %s", symbol, attempt, retries, exc)
            time.sleep(1.5 * attempt)
    logger.error("TV verisi alınamadı, sembol atlanıyor: %s (%s)", symbol, last_exc)
    return None


def get_indicators(symbol: str, finlab_db: Optional[dict] = None) -> Optional[dict]:
    """
    Tek bir sembol için 30dk + günlük teknik veriyi, yerel hacim SMA20'yi
    ve Finlab temel verisini birleştirip tek satırlık dict döner.
    Veri çekilemezse None döner (çağıran taraf sembolü atlamalı).
    """
    symbol = symbol.upper()
    intraday = _fetch_tv_analysis(symbol, Interval.INTERVAL_30_MINUTES)
    daily = _fetch_tv_analysis(symbol, Interval.INTERVAL_1_DAY)

    if intraday is None or daily is None:
        return None

    ind_30 = intraday.indicators
    ind_1d = daily.indicators

    macd_hist = None
    if ind_30.get("MACD.macd") is not None and ind_30.get("MACD.signal") is not None:
        macd_hist = ind_30["MACD.macd"] - ind_30["MACD.signal"]

    volume = ind_30.get("volume")
    vol_sma20 = _update_volume_history(symbol, volume)
    record_price_history(symbol, ind_30.get("close"))

    finlab_row = get_finlab_row(symbol, finlab_db)

    row = {
        "Symbol": symbol,
        "Close": ind_30.get("close"),
        "Open": ind_30.get("open"),
        "High": ind_30.get("high"),
        "Low": ind_30.get("low"),
        "Volume": volume,
        "RSI": ind_30.get("RSI"),
        "ADX": ind_30.get("ADX"),
        "EMA_50": ind_1d.get("EMA50"),
        "EMA_200": ind_1d.get("EMA200"),
        "MACD_Hist": macd_hist,
        "ATR": ind_30.get("ATR"),
        "Vol_SMA20": vol_sma20,
        "TV_Recommendation": daily.summary.get("RECOMMENDATION"),
        "TV_Recommendation_Intraday": intraday.summary.get("RECOMMENDATION"),
        "Finlab_Score": finlab_row["Finlab_Score"],
        "Fundamental_OK": finlab_row["Fundamental_OK"],
    }
    return row


def get_indicators_batch(symbols: list[str], finlab_db: Optional[dict] = None) -> pd.DataFrame:
    """Birden çok sembol için indikatör DataFrame'i üretir (sırasıyla, rate-limit korumalı)."""
    finlab_db = finlab_db if finlab_db is not None else load_finlab_data()
    rows = []
    for sym in symbols:
        row = get_indicators(sym, finlab_db)
        if row is not None:
            rows.append(row)
        else:
            logger.warning("Sembol veri alınamadığı için taramadan çıkarıldı: %s", sym)
    if not rows:
        return pd.DataFrame(columns=OUTPUT_COLUMNS)
    return pd.DataFrame(rows)[OUTPUT_COLUMNS]


# --------------------------------------------------------------------------- #
# Günlük trend kontrolü
# --------------------------------------------------------------------------- #
def check_daily_trend(row: dict) -> bool:
    """
    Günlük zaman diliminde yükseliş trendi kontrolü:
    EMA_50 > EMA_200 (altın kesişim bölgesi) VE Close > EMA_50.
    Gerekli veriler eksikse muhafazakâr davranıp False döner.
    """
    close, ema50, ema200 = row.get("Close"), row.get("EMA_50"), row.get("EMA_200")
    if None in (close, ema50, ema200):
        return False
    return ema50 > ema200 and close > ema50


if __name__ == "__main__":
    # Basit manuel test: `python indicators.py THYAO`
    import sys
    test_symbol = sys.argv[1] if len(sys.argv) > 1 else "THYAO"
    result = get_indicators(test_symbol)
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
