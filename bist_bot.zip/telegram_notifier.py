"""
telegram_notifier.py
---------------------
Telegram Bot API üzerinden metin ve grafik (fotoğraf) gönderimi.
Kimlik bilgileri ortam değişkenlerinden okunur (kod içine YAZILMAZ):
    TELEGRAM_BOT_TOKEN
    TELEGRAM_CHAT_ID
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

import requests

logger = logging.getLogger("telegram_notifier")

BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
API_BASE = "https://api.telegram.org/bot{token}"


def _configured() -> bool:
    if not BOT_TOKEN or not CHAT_ID:
        logger.warning("TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID tanımlı değil. "
                        "Bildirim gönderilmeyecek (yalnızca loglanacak).")
        return False
    return True


def send_message(text: str, parse_mode: str = "Markdown") -> bool:
    if not _configured():
        logger.info("[TELEGRAM-SIMULASYON] %s", text[:300])
        return False
    url = API_BASE.format(token=BOT_TOKEN) + "/sendMessage"
    try:
        resp = requests.post(
            url,
            data={"chat_id": CHAT_ID, "text": text, "parse_mode": parse_mode,
                  "disable_web_page_preview": True},
            timeout=15,
        )
        resp.raise_for_status()
        return True
    except requests.RequestException as exc:
        logger.error("Telegram mesaj gönderim hatası: %s", exc)
        return False


def send_photo(photo_path: str | Path, caption: str = "") -> bool:
    if not _configured():
        logger.info("[TELEGRAM-SIMULASYON] Grafik: %s | %s", photo_path, caption[:200])
        return False
    url = API_BASE.format(token=BOT_TOKEN) + "/sendPhoto"
    try:
        with open(photo_path, "rb") as f:
            resp = requests.post(
                url,
                data={"chat_id": CHAT_ID, "caption": caption, "parse_mode": "Markdown"},
                files={"photo": f},
                timeout=30,
            )
        resp.raise_for_status()
        return True
    except (requests.RequestException, OSError) as exc:
        logger.error("Telegram fotoğraf gönderim hatası: %s", exc)
        return False
